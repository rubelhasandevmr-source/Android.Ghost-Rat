AR <https://github.com/AHXR>
nlohmann <https://github.com/nlohmann>: json - https://github.com/nlohmann/json
benhoyt <https://github.com/benhoyt>: inih - https://github.com/benhoyt/inih