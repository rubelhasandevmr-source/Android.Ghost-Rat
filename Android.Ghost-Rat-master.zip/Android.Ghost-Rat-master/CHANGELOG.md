1.0.4 (1/21/2018)

- Task Manager Killer added
- Commands automatically timeout
- Cleaned up and organized some modules

1.0.3b (12/17/2017)

- Refresh crashing fixed
- Zombie's version of ghost now shown
- Now starts up in Safe Mode. (Administrator Privileges Required)
- Hidden from startup checkers such as CCleaner and msconfig (Administrator Privileges Required)

1.0.3a (12/17/2017)

- Fixed zombie not responding to commands
- IRC is now encrypted (substitution cipher)

1.0.2 (12/12/2017)

- Fixed repeated commands
- Windows version now shown
- Username of client now shown
- Antivirus shown 

1.0.1 (12/12/2017)

- Fixed incorrect CHANGELOG.md
- Fixed zombie not automatically reconnecting to server
- Server now has the ability to save/load configuration (**ghost.conf**)
- Fixed zombie not closing TCP connection.